# Final Research Report

## 1. Introduction and task
Compare baseline one-shot retrieval+synthesis vs custom MAS with optional LLM evaluator on 8 topics.

## 2. Architecture
- Baseline: Wikipedia + OpenAlex -> single Ollama synthesis (deterministic fallback).
- MAS: staged tools, filtering, supervisor stops, Ollama synthesis.
- Evaluator: Ollama JSON rubric when use_evaluator=True; deterministic otherwise.
- State: AgentState trace with payload and source/note deltas.

## 3. Evaluation methodology
Metric groups: result quality, process quality, operational, summary rubric.

## 4. Experiment design
8 topics x {baseline, agent, agent+evaluator}; ablations source_limit and max_steps.

## 5. Results

### 5.1 Per-topic registration table

### 5.2 Aggregated comparison (three configurations)

### 5.3 Quality vs process tradeoff
Baseline vs agent: rubric delta=+0.09; latency +11.4%; steps +233.3%. Weigh rubric gains against latency/step cost.

Agent vs agent+evaluator: rubric delta=-0.73; latency -6.3%.

### 5.4 Ablation
See Stage 6 line plots for source_limit and max_steps.

## 6. Failure case studies (>=3)

## 7. Final conclusion
Recommended variant: mas because higher completeness, similar or fewer tool errors.

## 8. Reproducibility
Model llama3.1 at http://127.0.0.1:11434; REPLAY_ONLY=False.